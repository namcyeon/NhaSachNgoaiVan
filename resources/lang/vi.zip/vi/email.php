<?php
return [
    'thank_you_for_your_order' => 'Cảm ơn bạn đã đặt hàng của bạn',
'msg_bacs_paypal' => 'Đơn đặt hàng của bạn đang bị giữ lại cho đến khi chúng tôi xác nhận thanh toán đã được nhận. Chi tiết đơn hàng của bạn được hiển thị dưới đây để bạn tham khảo',
'msg_cod' => 'Đơn đặt hàng của bạn đã nhận được và hiện đang được xử lý. Chi tiết đơn đặt hàng của bạn được hiển thị bên dưới để bạn tham khảo',
'our_bank_details' => 'Chi tiết của Ngân hàng chúng tôi',
'account_number' => 'Số tài khoản',
'sort_code' => 'Sort code',
'order' => 'Gọi món',
'product' => 'Sản phẩm',
'quantity' => 'Số lượng',
'price' => 'Giá bán',
'total' => 'Toàn bộ',
'subtotal' => 'Tổng cộng',
'shipping_cost' => 'Giá vận chuyển',
'free' => 'Miễn phí',
'tax' => 'Thuế',
'payment_method' => 'Phương thức thanh toán',
'customer_details' => 'Chi tiết khách hàng',
'email' => 'E-mail',
'tel' => 'Tel',
'billing_address' => 'Địa chỉ Thanh toán',
'powered_by' => 'Được hỗ trợ bởi',

    
];
