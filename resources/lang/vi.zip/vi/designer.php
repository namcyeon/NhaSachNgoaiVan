<?php
return [
    'maxfilesexceeded_msg' => 'Bạn đã tải lên nhiều hơn 1 Hình ảnh. Chỉ có tập tin đầu tiên sẽ được tải lên!',
'file_larger' => 'Tệp lớn hơn 1Mb!',
'image_file_validation' => 'Vui lòng chỉ tải lên tệp hình ảnh!',
'good_job' => 'Làm tốt lắm!',
'image_upload_success' => 'Đã tải lên thành công hình ảnh của bạn!',
'designer_price_can_not_zero' => 'Giá không thể bằng không',
'designer_product_out_of_stock' => 'Hiện tại, sản phẩm này đã hết hàng',
'designer_item_added_successfully' => 'Mục của bạn được thêm thành công',
'designer_cart_page_view' => 'Bạn có muốn xem trang giỏ hàng không?',

];
